# BMImonkeysdecodemonkeys
Set of functions built by Luis Chaves Rodriguez, Francesco Guagliardo and Daniele Olmeda for the purpose of the Brain-Machine Interfaces coursework of 2019.
All functions are MatLab functions
